import FreeSimpleGUI as sg
from zipcreator import make_archive

label1 = sg.Text("Select files to compress")
input1 = sg.Input()
choose_button1 = sg.FilesBrowse("Choose", key="files")

label2 = sg.Text("Select the destination folder")
input2 = sg.Input()
choose_button2 = sg.FolderBrowse("Choose", key="folder")

compress_button = sg.Button("Compress")

window = sg.Window("File Compressor", layout=[[label1, input1, choose_button1], [label2, input2, choose_button2], [compress_button]])

while True:
    event, values = window.read()
    filepath = values["files"].split(";")
    folderpath = values["folder"]
    make_archive(filepath, folderpath)




    
    

    print(event, values)
